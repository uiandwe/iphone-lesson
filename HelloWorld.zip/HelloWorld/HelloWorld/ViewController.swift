//
//  ViewController.swift
//  HelloWorld
//
//  Created by C3-24 on 2016. 9. 19..
//  Copyright © 2016년 C3-24. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    
    @IBOutlet weak var blackView: UIView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        let react = CGRect(x: 20, y:20, width: 200, height: 200)
        let redView = UIView(frame: react)
        redView.backgroundColor = UIColor.redColor()
        
        self.view.addSubview(redView)
        
        
        let blueView = UIView()
        blueView.frame = CGRect(x: 10, y: 10, width:100, height: 100)
        blueView.backgroundColor = UIColor(red: 0, green: 0, blue: 1, alpha: 1.0)
        
        redView.addSubview(blueView)
        
        
    }

    
    override func viewWillAppear(animated: Bool) {
        print("viewWillAppear")
    }
    
    override func viewDidAppear(animated: Bool) {
        let view99 = view.viewWithTag(99)
        view99?.backgroundColor = UIColor.blueColor()
        
        blackView.backgroundColor = UIColor.yellowColor()
    }
    
    override func viewDidLayoutSubviews() {
        print("viewDidLayoutSubviews")
    }
    
    override func viewWillLayoutSubviews() {
        print("viewWillLayoutSubviews")
    }
    
    override func viewWillDisappear(animated: Bool) {
        print("viewWillDisappear")
    }
}

