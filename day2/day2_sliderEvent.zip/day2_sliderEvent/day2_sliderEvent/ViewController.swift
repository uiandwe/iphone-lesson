//
//  ViewController.swift
//  day2_sliderEvent
//
//  Created by C3-24 on 2016. 9. 20..
//  Copyright © 2016년 C3-24. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var label: UILabel!
    
    
    @IBOutlet weak var stepper: UIStepper!
    @IBOutlet weak var slider: UISlider!
    
    @IBOutlet weak var colorView: UIView!
    
    @IBOutlet weak var redSlider: UISlider!
    @IBOutlet weak var greenSlider: UISlider!
    @IBOutlet weak var blueSlider: UISlider!
    
    
    @IBOutlet weak var redLabel: UILabel!
    @IBOutlet weak var greenLabel: UILabel!
    @IBOutlet weak var blueLabel: UILabel!
    
    @IBAction func colorChanged() {
        let r = redSlider.value
        let g = greenSlider.value
        let b = blueSlider.value
        let color = UIColor(red: CGFloat(r), green: CGFloat(g), blue: CGFloat(b), alpha: 1)
        colorView.backgroundColor = color
        
        redLabel.text = String (stringInterpolationSegment:CGFloat(r))
        greenLabel.text = String (stringInterpolationSegment:CGFloat(g))
        blueLabel.text = String (stringInterpolationSegment:CGFloat(b))
        
    }

    @IBAction func switchChanged(sender: UISwitch){
        redSlider.enabled = sender.on
        greenSlider.enabled = sender.on
        blueSlider.enabled = sender.on
        if sender.on {
            colorChanged()
        }
        else{
            colorView.backgroundColor = UIColor.grayColor()
        }
    }
    
    
    @IBAction func stepperAction(sender: AnyObject) {
        let v = Int(stepper.value)
        label.text = "\(v)"
        slider.value = Float(v)
    }
    
    @IBAction func sliderAction(sender: AnyObject) {
        let v = Int(slider.value)
        label.text = "\(v)"
        slider.value = Float(v)
        stepper.value = Double(v)
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

