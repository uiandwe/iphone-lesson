//
//  ViewController.swift
//  day2_buttonEvent
//
//  Created by C3-24 on 2016. 9. 20..
//  Copyright © 2016년 C3-24. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var colorView: UIView!
    
    
    @IBAction func handleClick(sender: AnyObject) {
        print("click", sender)
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        let button = UIButton()
        button.frame = CGRect(x: 50, y : 200, width : 100, height : 50)
        button.setTitle("button", forState: .Normal)
        button.setTitleColor(UIColor.blackColor(), forState: .Normal)
        button.setTitle("Highlighted", forState: .Highlighted)
        button.setBackgroundImage(nil, forState: .Disabled)
        button.addTarget(self, action: #selector(onClicked), forControlEvents: .TouchUpInside)
        self.view.addSubview(button)
        
        
        let button2 = UIButton()
        button2.frame = CGRect(x: 150, y : 200, width : 100, height : 50)
        button2.setTitle("button2", forState: .Normal)
        button2.setTitleColor(UIColor.blackColor(), forState: .Normal)
        button2.setBackgroundImage(nil, forState: .Disabled)
        
        button2.addTarget(self, action: #selector(colorRed), forControlEvents: .TouchUpInside)
        self.view.addSubview(button2)
        
        let button3 = UIButton()
        button3.frame = CGRect(x: 250, y : 200, width : 100, height : 50)
        button3.setTitle("button3", forState: .Normal)
        button3.setTitleColor(UIColor.blackColor(), forState: .Normal)
        button3.setBackgroundImage(nil, forState: .Disabled)
        
        button3.addTarget(self, action: #selector(colorYellow), forControlEvents: .TouchUpInside)
        self.view.addSubview(button3)
        
    }
    
    func onClicked(sender: UIButton){
        print("onclicked")
        colorView.backgroundColor = UIColor.grayColor()
    }
    
    func colorRed(sender: UIButton){
        colorView.backgroundColor = UIColor.redColor()
    }
    
    func colorYellow(sender: UIButton){
        colorView.backgroundColor = UIColor.yellowColor()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

