//
//  ViewController.swift
//  images
//
//  Created by C3-24 on 2016. 9. 19..
//  Copyright © 2016년 C3-24. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
        let image1 = UIImage(named: "image")
        let imageView1 = UIImageView(image: image1)
        self.view.addSubview(imageView1)
        
        let imagePath : String = NSBundle.mainBundle().pathForResource("image", ofType: "png")!
        let image2 = UIImage(contentsOfFile: imagePath)
        let imageView2 = UIImageView(frame: CGRectMake(0, 600, (image2?.size.width)!, (image2?.size.height)!))
        imageView2.image = image2
        self.view.addSubview(imageView2)
        
        
        let urlStr = "http://lorempixel.com/600/300/cats/"
        if let imageUrl = NSURL(string: urlStr),
            let imageData = NSData(contentsOfURL: imageUrl){
            let image3 = UIImage(data: imageData)
            
            let imageView3 = UIImageView(frame: CGRectMake(50, 350, 200, 100))
            imageView3.image = image3
            self.view.addSubview(imageView3)
        }
        
        let image4 = UIImage(named: "transparent")
        let imageView4 = UIImageView(image: image4)
        imageView4.center = CGPointMake(100, 350)
        self.view.addSubview(imageView4)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

