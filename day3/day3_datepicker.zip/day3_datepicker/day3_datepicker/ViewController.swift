//
//  ViewController.swift
//  day3_datepicker
//
//  Created by C3-24 on 2016. 9. 21..
//  Copyright © 2016년 C3-24. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    var timer : NSTimer!
    @IBOutlet weak var datePicker: UIDatePicker!
    @IBAction func startTimer(sender: AnyObject) {
        timer = NSTimer.scheduledTimerWithTimeInterval(1.0, target: self, selector: #selector(handlerTime(_:)), userInfo: nil, repeats: true)
    }
    
    func handlerTime(timer : NSTimer){
        print("handelr time")
        datePicker.countDownDuration -= 60
        timer.invalidate()
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

