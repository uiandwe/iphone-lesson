//
//  ViewController.swift
//  day3_pickerView
//
//  Created by C3-24 on 2016. 9. 21..
//  Copyright © 2016년 C3-24. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UIPickerViewDelegate, UIPickerViewDataSource {

    let data = ["a", "b", "c", "d", "E", "f", "g", "h", "i", "j"]
    
    func numberOfComponentsInPickerView(pickerView: UIPickerView) -> Int{
        return 2
    }
    
    func pickerView(pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int{
        if 0 == component{
            return data.count
        }
        else{
            return 10
        }
    }
    
    func pickerView(pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        
        if 0 == component{
            return data[row]
        }
        else{
            return "item : c\(component), r:\(row)"
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        let picker = UIPickerView()
        picker.delegate = self
        picker.dataSource = self
        
        picker.center = self.view.center
        self.view.addSubview(picker)
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

