//
//  ViewController.swift
//  day3_alert
//
//  Created by C3-24 on 2016. 9. 21..
//  Copyright © 2016년 C3-24. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBAction func showAlert(sender: AnyObject) {
        let dialog = UIAlertController(title: "title", message: "message", preferredStyle: UIAlertControllerStyle.Alert)
//        presentViewController(dialog, animated: true, completion: nil)
        
        
        let cancelAction  = UIAlertAction(title: "cancel", style: .Default){
            (action : UIAlertAction) in
            print("cancel")
        }
        dialog.addAction(cancelAction)
        
        
        let okAction = UIAlertAction(title: "ok", style: .Default){
            (action : UIAlertAction) in
            print("ok")
            let userInput = dialog.textFields![0]
            print("input : ", userInput.text)
        }
        dialog.addAction(okAction)
        
        dialog.addTextFieldWithConfigurationHandler{
            (textField) in textField.keyboardType = .NumberPad
            textField.secureTextEntry = true
        }
        
        presentViewController(dialog, animated: true, completion: {
                print("presented!")
        })
        
    }
    
    @IBAction func showActionSheet(sender: AnyObject) {
        let dialog = UIAlertController(title: "title", message: "message", preferredStyle: .ActionSheet)
        
        let cancelAction  = UIAlertAction(title: "cancel", style: .Default){
            (action : UIAlertAction) in
            print("cancel")
        }
        dialog.addAction(cancelAction)
        
        
        let okAction = UIAlertAction(title: "ok", style: .Default){
            (action : UIAlertAction) in
            print("ok")
        }
        dialog.addAction(okAction)
        
        
        presentViewController(dialog, animated: true, completion: {
            print("presented!")
        })

    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

