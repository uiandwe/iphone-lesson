//
//  ViewController.swift
//  day3_textfiled
//
//  Created by C3-24 on 2016. 9. 21..
//  Copyright © 2016년 C3-24. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    weak var activeTextFiled : UITextField?
    
    @IBAction func textFiledEditingDidBegin(sender: AnyObject) {
        print(sender)
        activeTextFiled = sender as? UITextField
    }
    
    @IBAction func textFieldEditingDidEnd(sender: AnyObject) {
        activeTextFiled?.resignFirstResponder()
        activeTextFiled = nil
    }
    
    @IBAction func handelDidEndOnExit(sender: AnyObject) {
        activeTextFiled?.resignFirstResponder()
    }
    
    @IBAction func handeldismissKeyboard(sender: AnyObject) {
        print("press")
        activeTextFiled?.resignFirstResponder()
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        // 탭 동작 인식기
        let gestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(handleTap(_:)))
        // 씬의 배경 뷰에 탭 동작 인식기 등록
        self.view.addGestureRecognizer(gestureRecognizer)
        
    }
    
    override func viewDidAppear(animated: Bool) {
        // 키보드 알림 감시 객체 등록
        NSNotificationCenter.defaultCenter().addObserver(self, selector: #selector(keyboardWillShow(_:)), name: UIKeyboardDidShowNotification, object: nil)
        NSNotificationCenter.defaultCenter().addObserver(self, selector: #selector(keyboardWillHide(_:)), name: UIKeyboardWillHideNotification
            , object: nil)
    }

    override func viewWillDisappear(animated: Bool) {
        NSNotificationCenter.defaultCenter().removeObserver(self)
    }
    func keyboardWillShow(noti : NSNotification){
        print("키보드가 나타났다.")
        
        
        if let rectObj = noti.userInfo?[UIKeyboardFrameEndUserInfoKey] as? NSValue {
            let keyboardRect = rectObj.CGRectValue()
            
            print("userinfo : \(noti.userInfo)")
            print("keyboard Rect : \(keyboardRect)")
            
            // 최초 응답 객체 찾기
            let textField = findFirstResponder() as! UITextField
            print("TextField rect : \(textField.frame)")
            // 키보드에 가리는지 체크
            if CGRectContainsPoint(keyboardRect, textField.frame.origin) {
                print("키보드에 가림")
                let dy = keyboardRect.origin.y - textField.frame.origin.y - textField.frame.size.height - 10
                self.view.transform = CGAffineTransformMakeTranslation(0, dy)
            }
            else {
                print("키보드에 가리지 않음")
            }
        }
        
        let rect = (noti.userInfo![UIKeyboardFrameEndUserInfoKey] as! NSValue).CGRectValue()
        
        print("keyboard height:", rect.height)
        
        
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    
    override func viewDidDisappear(animated: Bool) {
        // 감시 객체 삭제
        NSNotificationCenter.defaultCenter().removeObserver(self)
    }
    
  
    
    // 키보드가 사라지는 알림 처리
    func keyboardWillHide(noti : NSNotification) {
        self.view.transform = CGAffineTransformIdentity
    }
    
    func findFirstResponder() -> UIResponder? {
        for v in self.view.subviews {
            if v.isFirstResponder() {
                return (v as UIResponder)
            }
        }
        return nil
    }
    
    func handleTap(gesture : UITapGestureRecognizer) {
        // 최초 응답 객체 찾기
        if let firstRespond = self.findFirstResponder() {
            firstRespond.resignFirstResponder()
        }
    }
    
    

}

